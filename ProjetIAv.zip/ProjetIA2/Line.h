#ifndef DEF_LINE
#define DEF_LINE

#include <iostream>
#include <vector>

class Line
{
	public:

	Line(int i_posX1, int i_posY1, int i_posX2, int i_posY2);

	int posX1;
	int posY1;
	int posX2;
	int posY2;
};

#endif