#include "Line.h"
#include <vector>
#include <iostream>

using namespace std; 

Line::Line(int i_posX1, int i_posY1, int i_posX2, int i_posY2): posX1(i_posX1), posY1(i_posY1), posX2(i_posX2), posY2(i_posY2)
{
}